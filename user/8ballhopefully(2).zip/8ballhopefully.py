question = input("What would you like to ask the oh so wise and superior ball of the 8 variety? ")
#below is supposed to pick a random response
from random import randint
answers = (randint(0, 9))
if answers == 0:
    print ("dont even think about it")
if answers == 1:
    print ("something else would probably work better")
if answers == 2:
    print ("not a great idea")
if answers == 3:
    print ("what do you think I am, a doctor?")
if answers == 4:
    print ("that was the least stupid thing you have asked all day. Yes. Definitely... maybe")
if answers == 5:
    print ("I reckon that might work")
if answers == 6:
    print ("I hope no lives depend on this because I have no clue")
if answers == 7:
    print ("that might have a possibility of maybe having a chance of working in some alternate universe")
if answers == 8:
    print ("I hate to be boring, but Yes")
if answers == 9:
    print ("I have never been so certain that something is going to work out perfectly")
thisthing = 1
while thisthing == 1:
    question = input("Anything else you would like to ask the oh so wise and superior ball of the 8 variety? ")
    from random import randint
    answers = (randint(0, 9))
    if answers == 0:
        print ("dont even think about it")
    if answers == 0:
        print ("dont even think about it")
    if answers == 1:
        print ("something else would probably work better")
    if answers == 2:
        print ("not a great idea")
    if answers == 3:
        print ("what do you think I am, a doctor?")
    if answers == 4:
        print ("that was the least stupid thing you have asked all day. Yes. Definitely... maybe")
    if answers == 5:
        print ("I reckon that might work")
    if answers == 6:
        print ("I hope no lives depend on this because I have no clue")
    if answers == 7:
        print ("that might have a possibility of maybe having a chance of working in some alternate universe")
    if answers == 8:
        print ("I hate to be boring, but Yes")
    if answers == 9:
        print ("I have never been so certain that something is going to work out perfectly")
