name = input("Your name: ")
print ("Hello " + (name) + "! My name is Matthew")
#I am hungry for some curry right now
